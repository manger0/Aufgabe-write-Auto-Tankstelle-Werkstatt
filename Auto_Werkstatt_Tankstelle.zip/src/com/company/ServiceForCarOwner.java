package com.company;

public  abstract class ServiceForCarOwner {

    //Methodes
    public abstract void service (Auto car);
}
