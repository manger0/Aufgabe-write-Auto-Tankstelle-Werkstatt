package com.company;

public class Werkstatt extends ServiceForCarOwner{

    // Methodes
    @Override
    public void service(Auto car) {
        car.setGeld(car.getGeld() - 500);
        car.setKM_Bis_Service(5000);
        System.out.println("Auto wurde geserviced und 500$ abgebucht");
    }
}
