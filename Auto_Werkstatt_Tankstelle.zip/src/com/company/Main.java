package com.company;

public class Main {

    public static void main(String[] args) {
        Auto BMW = new Auto("BMW", 150, 50000, 5000, 50, 5000);
        System.out.println(BMW.toString());
        BMW.fahren(1000);
        System.out.println(BMW.toString());
        BMW.fahren(2560);
        BMW.fahren(2560);
        System.out.println(BMW.toString());
        Auto Opel = new Auto("Opel", 80, 180000, 10000, 20, 500);
        System.out.println(Opel.toString());
        Opel.fahren(200);
        System.out.println(Opel.toString());
    }
}
